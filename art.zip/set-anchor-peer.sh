#!/bin/bash


CHANNEL=${1}
# ORG =$2
ORGMSP=${2}
ORDERER_DOMAIN=${3}
HOST=${4}
PORT=${5}
# ORDERER_DOMAIN=${4}

echo $CHANNEL
echo $ORGMSP




# setGlobals $ORG
# set -x
# peer channel fetch config config_block.pb -o $ORDERER_DOMAIN  -c $CHANNEL --tls --cafile "$ORDERER_CA"
# { set +x; } 2>/dev/null
set -x
peer channel fetch config config_block.pb -o $ORDERER_DOMAIN  -c $CHANNEL --tls --cafile "$ORDERER_CA" --clientauth --certfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/crypto-config/peerOrganizations/oneplus/users/Admin@oneplus/tls/client.crt --keyfile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/crypto-config/peerOrganizations/oneplus/users/Admin@oneplus/tls/client.key
{ set +x; } 2>/dev/null

set -x
configtxlator proto_decode --input config_block.pb --type common.Block | jq .data.data[0].payload.data.config > config.json
{ set +x; } 2>/dev/null

#adding org msp from config block
# set -x
# jq -s '.[0] * {"channel_group":{"groups":{"Application":{"groups": {'"$ORGMSP"':.[1]}}}}}' config.json ./$ORGMSP.json > modified_config.json
# { set +x; } 2>/dev/null
set -x
jq '.channel_group.groups.Application.groups.'"$ORGMSP"'.values += {"AnchorPeers":{"mod_policy": "Admins","value":{"anchor_peers": [{"host": "'$HOST'","port": '$PORT'}]},"version": "0"}}' config.json > modified_config.json

{ set +x; } 2>/dev/null

set -x
configtxlator proto_encode --input config.json --type common.Config --output config.pb
{ set +x; } 2>/dev/null

set -x
configtxlator proto_encode --input modified_config.json --type common.Config --output modified_config.pb
{ set +x; } 2>/dev/null

set -x
configtxlator compute_update --channel_id $CHANNEL --original config.pb --updated modified_config.pb --output update.pb
{ set +x; } 2>/dev/null

set -x
configtxlator proto_decode --input update.pb --type common.ConfigUpdate | jq . > update.json
{ set +x; } 2>/dev/null

set -x
echo '{"payload":{"header":{"channel_header":{"channel_id":"'"$CHANNEL"'", "type":2}},"data":{"config_update":'$(cat update.json)'}}}' | jq . > update_in_envelope.json
{ set +x; } 2>/dev/null

set -x
configtxlator proto_encode --input update_in_envelope.json --type common.Envelope --output update_in_envelope.pb
{ set +x; } 2>/dev/null